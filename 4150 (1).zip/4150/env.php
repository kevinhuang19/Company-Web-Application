<?php
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'voh_4150db');
    define('DB_USER', 'voh_4150db');
    define('DB_PASSWORD', 'Menlun123@');    ?>