<nav class="navbar navbar-expand-md bg-dark navbar-dark">
      <!-- Navbar links -->
    <div class="container">
      <a class="navbar-brand" style="font-size:20px" href="home.php">The Company</a>
  
    <!-- Navbar links -->
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="list.php">Employee List </a>
            </li>
          
          <li class="nav-item">
                <a class="nav-link" href="searchproject.php">Project List</a>
            </li>
         
          <li class="nav-item">
                <a class="nav-link" href="search1.php">Works On List</a>
            </li>
          <li class="nav-item">
                <a class="nav-link" href="departmentlist.php">Department List</a>
            </li>
     <li class="nav-item">
                <a class="nav-link" href="dependents.php">Dependents List</a>
            </li>
         
        </ul>
    </div>
</nav>